package search.selenium.tests;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang3.time.StopWatch;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.jetty.util.TestCase;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchTest {
	private WebDriver d;
	private String baseUrl;
	private boolean acceptNextAlert=true;
	private StringBuffer verErrors=new StringBuffer();
	Logger logger = LoggerFactory.getLogger(TestCase.class);
	
	@Before
	public void setUp() throws Exception{
		d = new FirefoxDriver();
		baseUrl = "http://rspa.ndc.lucent.com:8050/rsp/";
		d.manage().window().maximize();
	}
	
	
	@Test
	public void timeAndSearchBy() throws Exception{
		long start = System.currentTimeMillis();
		d.get(baseUrl);
		long finish = System.currentTimeMillis();
		long totalTimeMilis = finish - start; 
		float totalTimeSec = (float)totalTimeMilis/1000;
		System.out.println("Total time for page load: "+totalTimeSec+" seconds"); 
		
		//Put correct data and sign in 
		StopWatch pageLoad = new StopWatch();
        pageLoad.start();
		d.findElement(By.id("username")).sendKeys("pnitubyd");
		d.findElement(By.id("password")).sendKeys("Ravs2016!");
		d.findElement(By.cssSelector("*[class^='btn btn-small']")).click();
		WebDriverWait wait = new WebDriverWait(d, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("navBanner")));
        pageLoad.stop();
        
        //Get the time
        long pageLoadTime_ms = pageLoad.getTime();
        float pageLoadTime_Seconds = (float)pageLoadTime_ms / 1000;
        System.out.println("Total login time: " + pageLoadTime_Seconds + " seconds");
        Thread.sleep(3000);
        
		//Get into Data Catalog
		WebElement menuElements = d.findElement(By.cssSelector("*[class^='row n-banner-2nd']"));
		List<WebElement> links = menuElements.findElements(By.tagName("li"));
		System.out.println("You are going into: "+links.get(0).getText());
		links.get(0).click();
		
		//Choose dates from calendars 
		//***RANDOM EXAMPLE***
		//First calendar
		Thread.sleep(4000);
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/button")).click();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/table/tbody/tr[2]/td[4]/span/button")).click();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/div[2]/div/div/input")).clear();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/div[2]/div/div/input")).sendKeys("10");
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/div[2]/div[2]/div/input")).clear();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/div[2]/div[2]/div/input")).sendKeys("30");
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_BD']/div/div/div/div/div[2]/div[4]/button[2]")).click();
		
		//Second calendar
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/button")).click();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/table/tbody/tr[3]/td[4]/span/button")).click();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/div[2]/div/div/input")).clear();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/div[2]/div/div/input")).sendKeys("17");
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/div[2]/div[2]/div/input")).clear();
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/div[2]/div[2]/div/input")).sendKeys("15");
		d.findElement(By.xpath("//div[@id='calendar_datetime_24hour_ED']/div/div/div/div/div[2]/div[4]/button[2]")).click();
		
		
		
		//---------------------***BY NETWORK ELEMENT EXAMPLE***-----------------------
		
		
		processDataTypes(1);
		
		//***CHOOSE NETWORK ELEMENT***
		
//		d.findElement(By.xpath("/html/body/div[3]/form/div/div[3]/div/div[1]/div/div[1]/div/div/table/tbody/tr[2]/td[2]/table/tbody/tr[1]/td[2]/img")).click();
//		d.findElement(By.xpath("//div[@id='dsNeTreeWrapperMain']/div[2]/button")).click();
//		//New window 
//		Thread.sleep(5000);
//		String parent=d.getWindowHandle();
//		String child=null;
//		Set<String> handles=d.getWindowHandles();
//		Iterator<String> iter=handles.iterator();
//		while(iter.hasNext()){ //Get all window handles
//			child=iter.next();
//		}
//		d.switchTo().window(child);
//		d.close();
//		d.switchTo().window(parent);
		
		
		//---------------------***BY SERVICES EXAMPLE***-----------------------
		
		
//		processDataTypes(2);
		
		Thread.sleep(30000);
		doubleClick(d.findElement(By.xpath("/html/body/div[3]/form/div/div[3]/div/div[1]/div/div[1]/div/div/table/tbody/tr[2]/td[2]/table/tbody/tr[1]/td[4]/span")));
		
		
	}
	
	
	
	
	@After
	public void tearDown() throws Exception{
//		d.quit();
		String verErrorString = verErrors.toString();
		if(!"".equals(verErrorString)){
			logger.error(verErrorString);
		}
	}
	
	//function, which write number of element for each data type and choose first for example test

	private void processDataTypes(int index) throws InterruptedException{
		//Search by 
		d.findElement(By.xpath("//div[@id='searchByList']/button")).click();
		d.findElement(By.xpath("//ul[@id='searchByUL']/li["+index+"]/a/span")).click();
	
		//Click next
		d.findElement(By.id("nextBtn1")).click();
		Thread.sleep(6000);
		
		//Getting into specific Data Type 
		//***1360COM EXAMPLE***
		d.findElement(By.xpath("//div[@id='DSdtTree']/div/table/tbody"));
		System.out.println("You are into: "+d.findElement(By.xpath("//tr/td/span[contains(text(), 'All Data Types')]")).getText());
		List<WebElement> dataTypeList=d.findElements(By.xpath("//div[@id='DSdtTree']/div/table/tbody/tr[2]/td[2]/table/tbody/tr/td[2]/table/tbody/tr/td[4]/span"));
		System.out.println("Number of data types: "+dataTypeList.size());

		
		//Number of elements for each Data Type
		Iterator<WebElement> it = dataTypeList.iterator();
		int i = 0;
		while(it.hasNext()){
			if(i>dataTypeList.size()-1) break;
			//Select all data types
			JavascriptExecutor jse = (JavascriptExecutor)d; //Scroll to specific item to select it
			jse.executeScript("arguments[0].scrollIntoView()", dataTypeList.get(i)); 
			doubleClick(dataTypeList.get(i));
			List<WebElement> dataList = d.findElements(By.xpath("//div[@id='DSdtTree']/div/table/tbody/tr[2]/td[2]/table/tbody/tr["+(i+2)+"]/td[2]/table/tbody/tr/td[2]/table/tbody/tr/td[2]/img"));
			
			JavascriptExecutor jse2 = (JavascriptExecutor)d; //Scroll to specific item to select it
			jse2.executeScript("arguments[0].scrollIntoView()", dataTypeList.get(i));
			
			//Select two random data types if there are more than two elements
			if(dataList.size()>=2){
				ArrayList<Integer> numbers = new ArrayList<Integer>(); //Generate two random integers for each processed data type
				Random generator=new Random();
				while(numbers.size()<1){
					int rand = generator.nextInt(dataList.size());
					if(!numbers.contains(rand)){
						numbers.add(rand);
					}
				}
				
				System.out.println("Number of elements inside "+dataTypeList.get(i).getAttribute("textContent")+" : "+dataList.size());
				System.out.println("First random: "+numbers.get(0));
//				System.out.println("Second random: "+numbers.get(1));
				
				JavascriptExecutor jseFirstRandom = (JavascriptExecutor)d; //Scroll to specific item to select it
				jseFirstRandom.executeScript("arguments[0].scrollIntoView()", dataList.get(numbers.get(0))); 
				dataList.get(numbers.get(0)).click();
//				JavascriptExecutor jseSecondRandom = (JavascriptExecutor)d; //Scroll to specific item to select it
//				jseSecondRandom.executeScript("arguments[0].scrollIntoView()", dataList.get(numbers.get(1))); 
//				dataList.get(numbers.get(1)).click();
			}else if(dataList.size()<2){
				JavascriptExecutor jseFirstRandom = (JavascriptExecutor)d; //Scroll to specific item to select it
				jseFirstRandom.executeScript("arguments[0].scrollIntoView()", dataList.get(0)); 
				dataList.get(0).click();
			}
			
			i++;
		}
	
		d.findElement(By.xpath("//div[@id='dsTreeWrapperMain']/div[2]/button")).click();
		Thread.sleep(10000);
	}
	
	private void doubleClick(WebElement element){
		try{
			Actions action = new Actions(d).doubleClick(element);
			action.build().perform();
		}catch(Exception e){
			System.out.println("Element "+element+" was not clickable "+e.getStackTrace());
		}
	}
//	
//	private String closeAlertAndGetItsText(){
//		try{
//			Alert alert = d.switchTo().alert();
//			String alertText = alert.getText();
//			if(acceptNextAlert){
//				alert.accept();
//			} else {
//				alert.dismiss();
//			}
//			return alertText;
//		}finally{
//				acceptNextAlert=true;
//		}
//	}
}
